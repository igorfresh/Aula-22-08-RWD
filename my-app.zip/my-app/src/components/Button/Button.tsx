import {StyledButton} from "./Button.styled"

interface ButtonProps {
    children: string
    danger?: boolean
    success?: boolean
}

export const Button = ({ children, danger, success, ...rest }: ButtonProps) => {
    return<StyledButton danger={danger} success={success} {... rest}>{children}</StyledButton>
        
}
