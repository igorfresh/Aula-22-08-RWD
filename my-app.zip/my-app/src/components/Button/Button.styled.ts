import styled from "styled-components"

export const StyledButton = styled.button `
background-color: white;
border: 0;
padding: 16px;
cursor: pointer;
&:hover{
    background-color: lightgray;
}
&:focus{
    outline: 1px solid black;
}
&:disabled{
    background-color: blue;
}
${(props) => 
props.danger && 
`
background-color: red;
color: white;
`}
${(props) => 
props.success && 
`
background-color: green;
color: white;
`}
`