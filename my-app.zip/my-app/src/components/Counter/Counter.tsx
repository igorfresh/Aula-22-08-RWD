import { useState } from "react"
import { Button } from "../Button/Button"

interface CounterProps {
    step?: number
    start?: number
}

// step = prop
export const Counter = ({ step = 1, start = 0 }: CounterProps) => {

    // hook deve ser declarado antes de qualquer método
    // useState utiliza dois parametros
    const [count, setCount] = useState(start)
    const [isDisabled, setIsDisabled] = useState(true)

    // handle = indica um evento, pode estar em um botão ou campo do formulario
    const handleIncrement = () => {
        console.log("Incrementar")
        setCount(count + step)
        if (count > 0) {
            setIsDisabled(false)
        }
    }

    const handleDecrement = () => {
        console.log("Decrementar")
        setCount(count - step)
        if (count <= 10) {
            setIsDisabled(true)
        }
    }

    return (
        <div>
            <Button danger onClick={handleDecrement} disabled={isDisabled}>Decrementar</Button>
            <span>
                {count}
            </span>
            <Button success onClick={handleIncrement}>Incrementar</Button>
        </div>
    )
}