import { useState } from "react"

export const Form = () => {
        const [name, setName] = useState ("")
        const [surname, setSurname] = useState ("")
        const [birthday, setBirthday] = useState ("")
        const [estadocivil, setEstadocivil] = useState ("")
        const [rg, setDocumentoRG] = useState (false)
        const [cpf, setDocumentoCPF] = useState (false)
        const [termos, setTermos] = useState (false)

        const handleChangeName = (event) => {
            setName(event.target.value)
        }
        const handleChangeSurname = (event) => {
            setSurname(event.target.value)
        }
        const handleChangeBirthday = (event) => {
            setBirthday(event.target.value)
        }
        const handleChangeEstadocivil = (event) => {
            setEstadocivil(event.target.value)
        }
        const handleRadioRG = (event) => {
            setDocumentoRG(event.target.checked)
        }
        const handleRadioCPF = (event) => {
            setDocumentoCPF(event.target.checked)
        }
        const handleCheck = (event) => {
            setTermos(event.target.checked)
        }
        const handleSave = () => {
            const payload = {
                nome: name,
                sobrenome: surname,
                estadoCivil: estadocivil,
                dataNascimento: birthday,
                documento: cpf ? 'CPF' : 'RG',
                termos: termos
            }

            console.log(payload)
        }

    return (
    <form>

        <h3>
        {name},{surname}, {birthday}, {estadocivil}
        </h3>
        <div>
            <label htmlFor="name">Nome</label>
            <input type="text" id="name" onChange={handleChangeName}/>
            <br />
            <label htmlFor="surname">Sobrenome</label>
            <input type="text" id="surname" onChange={handleChangeSurname} />
            <br />
            <label htmlFor="birthday">Data de Nascimento</label>
            <input type="date" id="birthday" onChange={handleChangeBirthday}/>
            <br />
            <label htmlFor="estado-civil">Estado Civil</label>
            <select name="select" id="estado-civil" onChange={handleChangeEstadocivil}>
                <option value="">Qual seu estado civil?</option>
                <option value="solteiro">Solteiro</option>
                <option value="casado">Casado</option>
                <option value="divorciado">Divorciado</option>
                <option value="viuvo">Viúvo</option>
            </select>
            <br/>
            <legend>Documento</legend>
            <label htmlFor="rg">RG</label>
            <input type="radio" name="document" id="CPF" onChange={handleRadioRG}/>
            <label htmlFor="cpf">CPF</label>
            <input type="radio" name="document" id="RG" onChange={handleRadioCPF}/>
            <br />
            <label htmlFor="">Termos e Condições</label>
            <input type="checkbox" name="terms" id="terms" onChange={handleCheck} />
        </div>
        <div>
            <button type="button" onClick={handleSave}>Salvar</button>
        </div>
    </form>
    )
}