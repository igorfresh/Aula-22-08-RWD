import styled from "styled-components"


export const StyledHeader = styled.header `
width: 100%;
height: 90px;
background-color: purple;
display: flex;
justify-content: space-around;
align-items: center;
`