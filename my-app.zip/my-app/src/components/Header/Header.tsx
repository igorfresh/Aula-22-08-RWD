import {StyledHeader} from "./Header.styled"
import Logo from "../../assets/logo-brix.png"

interface HeaderProps
    {
    userName: string
    userImage?: string
}

export const Header = ({userName, userImage =""}: HeaderProps) => {
    return<StyledHeader>
                <img src={Logo} alt="Logotipo Brix" />
                <span>Olá, {userName}</span>
                <img src={Logo} alt=""/>
    </StyledHeader>
        
}