import { Button } from "./components/Button/Button"
// import JorgeAbreu from './assets/jose-de-abreu.jpg'
import { Header } from "./components/Header/Header"
import { Card } from "./components/Card/Card"
import { Counter } from './components/Counter/Counter'
import { Form } from "./components/Form/Form"

function App() {
  const user = {
    name: 'Jorge de Abreu',
    image: ""
  }  

  const products = [
    {id: 8, name: "Banana", value: 10},
    {id: 9, name: "Mamão", value: 12},
    {id: 10, name: "Maçã", value: 8},
  ]
  return (
    <>
      {/* <Header userName={user.name}/>
      <Button danger>Cancelar</Button>
      <Button success>Salvar o mundo</Button>
        {products.map(product => (
          <Card key={product.id}> 
          <h3>{product.name}</h3> 
          <p>{product.value}</p> 
          </ Card>
        ) )}
      <Counter step={1} start={1000}/> */}
      <Form />
    </>
  )
}

export default App
